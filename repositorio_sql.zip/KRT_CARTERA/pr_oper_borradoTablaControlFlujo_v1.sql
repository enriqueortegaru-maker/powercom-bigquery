BEGIN

  DECLARE VDESDE_1M INT64;
  --DECLARE VTIPO STRING; DECLARE VFECHA_CALC_DT DATE; DECLARE VDESDE, VVERSION INT64; SET VTIPO="EVENTOS";SET VDESDE=20251101;SET VFECHA_CALC_DT=CURRENT_DATE();SET VVERSION=23;
  SET VDESDE_1M=CAST(CAST(FORMAT_DATE("%Y%m%d",DATE_SUB(PARSE_DATE("%Y%m%d",CAST(VDESDE AS STRING)), INTERVAL 1 MONTH)) AS STRING) AS INT64);

  SELECT VDESDE, VDESDE_1M;

  IF TRIM(UPPER(VTIPO))="EVENTOS" THEN
    DELETE from `mm-commissions-reporting.KRT_CARTERA.FLUJO_UPD_TABLAS_PRINCIPALES`  WHERE contains_substr(Nombre,"EVENTOS_CARTERA") and version= VVERSION 
    and desde=VDESDE and fecha_calc_dt=VFECHA_CALC_DT;

    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_VENTAS_CARTERA` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_VENTAS_TERMINALES_INCENTIVOS` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;    
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_VENTAS_TELEVENTAS` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;        
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_VENTAS_TIENDAS` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;

    DELETE from `mm-commissions-reporting.KRT_CARTERA.FLUJO_UPD_TABLAS_PRINCIPALES`  WHERE contains_substr(Nombre,"EVENTOS_CARTERA") and version= VVERSION  and desde=VDESDE and fecha_calc_dt=VFECHA_CALC_DT;
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_EVENTOS_CARTERA` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;
  END IF;

  IF TRIM(UPPER(VTIPO))="DECOMISIONES" THEN
    DELETE from `mm-commissions-reporting.KRT_CARTERA.FLUJO_UPD_TABLAS_PRINCIPALES`  WHERE contains_substr(Nombre,"DECOMISIONES") and version= VVERSION 
    and desde=VDESDE and fecha_calc_dt=VFECHA_CALC_DT;
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_DECOMISIONES` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;
  END IF;



  IF TRIM(UPPER(VTIPO))="COMISIONES" THEN
    DELETE from `mm-commissions-reporting.KRT_CARTERA.FLUJO_UPD_TABLAS_PRINCIPALES`  WHERE contains_substr(Nombre,"COMISIONES") and version= VVERSION 
    and desde=VDESDE and fecha_calc_dt=VFECHA_CALC_DT;
    DELETE  FROM `mm-commissions-reporting.KRT_CARTERA.AGG_COMISIONES` where fecha_calc_dt=VFECHA_CALC_DT and desde=VDESDE and version=VVERSION;
  END IF;


END