BEGIN 

  CREATE OR REPLACE TABLE `mm-commissions-reporting.KRT_REPORTING.INV_PRODUCTOS_TCNET_12M` 
  PARTITION BY RANGE_BUCKET(idCliente, GENERATE_ARRAY(0, 1000000007, 250063)) AS 
  SELECT * FROM `mm-commissions-reporting.KRT_REPORTING.f_vt_debugInventarioProductosTcnet_12M`();

END