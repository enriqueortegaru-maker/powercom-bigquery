BEGIN


	-- VALOR PARAMETRO VTIPO
	--	"TOTAL": 			Actualizacion Captacion + Cartera
	--	"CAPTACION": 	Actualizacion Captacion
	--	"CARTERA":		Actualizacion Cartera


	DECLARE VHASTA INT64;
	DECLARE VMES_FACTURA_DT DATE;
	--DECLARE VDESDE INT64; DECLARE VTIPO STRING; SET VDESDE=20250301;SET VTIPO="CARTERA";	
	SET VMES_FACTURA_DT= PARSE_DATE('%Y%m%d',CAST(VDESDE AS STRING));
	SET VHASTA=CAST(FORMAT_DATE("%Y%m%d",LAST_DAY(PARSE_DATE("%Y%m%d",CAST(VHASTA AS STRING)))) AS INT64);


	IF contains_substr(VTIPO,"Total") OR contains_substr(VTIPO,"Captacion")  OR contains_substr(VTIPO,"Cartera") THEN



		--- PASO 1: CREO TABLA INTERMEDIA

		IF contains_substr(VTIPO,"Total") THEN 
				CREATE OR REPLACE TABLE `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO` AS 	
				SELECT * FROM `mm-commissions-reporting.KRT_SAP.TRANSACCIONES` WHERE 1=0;

			ELSEIF contains_substr(VTIPO,"Captacion") THEN 			
				CREATE OR REPLACE TABLE `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO` AS 	
				SELECT * FROM `mm-commissions-reporting.KRT_SAP.TRANSACCIONES` WHERE mes_factura_dt=VMES_FACTURA_DT and tipo="CARTERA";

			ELSEIF contains_substr(VTIPO,"Cartera") THEN 			
				CREATE OR REPLACE TABLE `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO` AS 	
				SELECT * FROM `mm-commissions-reporting.KRT_SAP.TRANSACCIONES` WHERE mes_factura_dt=VMES_FACTURA_DT and tipo="CAPTACION";

		END IF;


		--- PASO 2: INSERTO REGISTROS DE CAPTACION EN TABLA INTERMEDIA
		IF contains_substr(VTIPO,"Total") OR contains_substr(VTIPO,"Captacion") THEN		


			--- PASO 2.1: INSERTO COMISIONES
			INSERT `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO`
			(

				mes_factura_dt,
				mes_liquidado,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca,
				customer_id,
				service_id,
				concepto_ds_gekt,
				tariff_ds,
				tipo_concepto,
				activation_date,
				sale_date,
				canal_gekt,
				subcanal,
				distribuidor,
				seller,
				customer_dni,
				segmento,
				tariff_id,
				concepto,
				clase_concepto,
				order_id,
				account_id,
				bundle_type,
				marco,
				orden,
				comision,
				id_mes,
				sfid_id,
				agrupacion_canal,
				canal,
				subcanal_gekt,
				nombre_comercio,
				service_type,
				technology_ds,
				order_type_agg,
				bp,
				id_comisionista,
				cif,
				cod_marca,
				cod_segmento,
				sociedad,
				deactivation_date,
				unidades,
				zona_fiscal,
				billing_type_ds,
				operation,
				distribuidor_gekt,
				categoria_servicio_ds,
				clase,
				tipo,
				concepto_factura_ds
			)

			select 
				mes_factura_dt,
				mes_comision_dt,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca_ds,
				CAST(Cliente_id AS STRING),
				CAST(servicio_id AS STRING),
				CAST(concepto_ds AS STRING),
				detalle_servicio_ds,
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CAPTACION", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(detalle_servicio_ds,clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento_ds, desc_mm,""),
				EXTRACT(DATE FROM fecha_rfb_dt),
				EXTRACT(DATE FROM fecha_venta_neta_dt),
				canal_alta_ds,
				subcanal_ds,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_acreedor`(marca_ds, nombre_distribuidor_alta_ds),
				agente_alta_id,
				cif_nif,
				UPPER(TRIM(segmento_ds)),
				catalogo_id,
				desc_mm,
				clase_mm,
				pedido,
				CAST(contrato_id AS STRING),
				cat_plays_p,
				marco_Retributivo_ds,
				orden_sap,
				importe,
				mes_comision_id,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_sfid_id`(marca_ds, equipo_ds, agente_Alta_id),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_agrupacion_canalv1`(mes_factura_dt, marco_retributivo_ds, canal_alta_ds, subcanal_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_canal`(marco_retributivo_ds, canal_alta_ds, subcanal_ds),
				subcanal_ds,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_nombre_comercio`(canal_alta_ds, equipo_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_service_type`(categoria_servicio_ds, detalle_servicio_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_technology`(categoria_servicio_ds, tecnologia_detalle_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_order_type_agg`(portabilidad_in_lg),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cif_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cod_marca`(marca_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cod_segmento`(segmento_ds),
				`mm-commissions-reporting.KRT_SAP.f_obtieneSociedadDesdeMarca`(marca_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_deactivation_date`(),
				1,
				'PEN',
				'POSTPAID',
				'ALTA',
				nombre_distribuidor_alta_ds,
				--categoria_servicio_ds,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_categoria_servicio`(categoria_servicio_ds, tecnologia_detalle_ds),
				'COMISION',
				'CAPTACION',
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CAPTACION", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(detalle_servicio_ds,clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento_ds, desc_mm,"")
			from `mm-commissions-reporting.KRT_CAPTACION.HISTORICO_COMISIONES_CAPTACION_FACTURADO`
			where mes_factura_dt=vmes_factura_dt;


			--- PASO 2.2: INSERTO DECOMISIONES

			INSERT `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO`
			(
				mes_factura_dt,
				mes_liquidado,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca,
				customer_id,
				service_id,
				concepto_ds_gekt,
				tariff_ds,
				tipo_concepto,
				activation_date,
				sale_date,
				canal,
				subcanal,
				canal_gekt,
				subcanal_gekt,
				distribuidor,
				seller,
				customer_dni,
				segmento,
				marco,
				orden,
				comision,
				deactivation_date,
				causa_baja_agrup,
				causa_baja,
				id_mes,
				concepto,
				clase_concepto,
				sfid_id,
				agrupacion_canal,
				nombre_comercio,
				service_type,
				--technology_ds,
				--order_type_agg,
				bp,
				id_comisionista,
				cif,
				cod_marca,
				cod_segmento,
				sociedad,
				unidades,
				zona_fiscal,
				billing_type_ds,
				operation,
				distribuidor_gekt,
				categoria_servicio_ds,
				clase,
				tipo,
				concepto_factura_ds

			)

			select 
				mes_factura_dt,
				mes_decomision_dt,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca_ds,
				CAST(Cliente_id AS STRING),
				CAST(servicio_id AS STRING),
				CAST(concepto_ds AS STRING),
				detalle_servicio_ds,
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CAPTACION", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(detalle_servicio_ds, clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento_ds, desc_mm,"") ,
				EXTRACT(DATE FROM fecha_rfb_dt),
				EXTRACT(DATE FROM fecha_venta_neta_dt),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_canal`(marco_retributivo_ds, canal_alta_ds, subcanal_ds),
				subcanal_ds,
				canal_alta_ds,
				subcanal_ds,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_acreedor`(marca_ds, nombre_distribuidor_alta_ds),
				agente_alta_id,
				cif_nif,
				UPPER(TRIM(segmento_ds)),
				marco_retributivo_ds,
				orden_sap,
				importe,
				EXTRACT(DATE FROM fecha_baja_dt),
				motivo_baja_agrup_ds,
				motivo_baja_ds,
				mes_decomision_id,
				desc_mm,
				clase_mm,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_sfid_id`(marca_ds, equipo_ds, agente_Alta_id),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_agrupacion_canalv1`(mes_factura_dt, marco_retributivo_ds, canal_alta_ds, subcanal_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_nombre_comercio`(canal_alta_ds, equipo_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_service_type`(categoria_servicio_ds, detalle_servicio_ds),
				--`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_technology`(categoria_servicio_ds, tecnologia_detalle_ds),
				--`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_order_type_agg`(portabilidad_in_lg),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cif_comisionista`(marca_ds, nombre_distribuidor_alta_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cod_marca`(marca_ds),
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_cod_segmento`(segmento_ds),
				`mm-commissions-reporting.KRT_SAP.f_obtieneSociedadDesdeMarca`(marca_ds),
				1,
				'PEN',
				'POSTPAID',
				'BAJA',
				nombre_distribuidor_alta_ds,
				categoria_servicio_ds,
				'DECOMISION',
				'CAPTACION',
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CAPTACION", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(detalle_servicio_ds, clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento_ds, desc_mm,"") 
				from `mm-commissions-reporting.KRT_CAPTACION.HISTORICO_DECOMISIONES_CAPTACION_FACTURADO`
				where mes_factura_dt=vmes_factura_dt;

		END IF;


		--- PASO 3: INSERTO REGISTROS DE CARTERA EN TABLA INTERMEDIA
		IF contains_substr(VTIPO,"Total") OR contains_substr(VTIPO,"Cartera") THEN

			--- PASO 3.1: INSERTO COMISIONES
			INSERT `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO`
			(

				mes_factura_dt,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				mes_liquidado,
				id_mes,
				marca,
				account_id,
				tariff_id,
				tariff_ds,
				distribuidor,
				canal_gekt,
				subcanal,
				seller,
				customer_id,
				customer_dni,
				activation_date,
				segmento,
				tariff_id_origin,
				service_id_origin,
				tariff_ds_origin,
				operation_type,
				service_id,
				concepto_ds_gekt,
				concepto_lista_ds_gekt,
				concepto_origen_ds_gekt,
				marco,
				campaign_code,
				orden,
				tipo_concepto,
				comision,
				concepto,
				clase_concepto,
				sfid_id,
				agrupacion_canal,
				canal,
				subcanal_gekt,
				nombre_comercio,
				service_type,
				order_type_agg,
				bp,
				id_comisionista,
				cif,
				cod_marca,
				cod_segmento,
				sociedad,
				deactivation_date,
				unidades,
				zona_fiscal,
				billing_type_ds,
				operation,
				distribuidor_gekt,
				categoria_servicio_ds,
				clase,
				tipo,
				concepto_factura_ds
			)

			select 

				mes_factura_dt,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				mes_comision_dt,
				mes_comision_id,
				marca_ds,
				Contrato,
				IdCatalogo,
				NombreProducto,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_acreedor`(marca_ds, nombre_distribuidor),
				Canal,
				subcanal,
				agente,
				CAST(IdFijo AS STRING),
				DNI_CIF,
				Fecha_Activacion,
				UPPER(TRIM(Segmento)),
				CAST(idCatalogoOrigen AS STRING),
				CAST(IdProductoOrigen AS STRING),
				NombreProductoOrigen,
				tipoMovimiento,
				CAST(IdProducto AS STRING),
				concepto_ds,
				concepto_lista,
				concepto_origen_ds,
				MARCO_RETRIBUTIVO,
				coalesce(nombre_Campana,campana_id),
				orden_sap,
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CARTERA", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(nombreProducto, clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento, desc_mm, tipoMovimiento),
				importe,
				desc_mm,
				clase_mm,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_sfid_id`(marca_ds, agente,usuarioCreador),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_agrupacion_canalv1`(mes_factura_dt, marco_retributivo, canal, subcanal),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_canal`(marco_retributivo, canal, subcanal),
				subcanal,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_nombre_comercio`(marca_ds, canal, agente),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_service_type`(TipoProducto),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_order_type_agg`(TipoMovimiento,''),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cif_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cod_marca`(marca_ds),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cod_segmento`(segmento),
				`mm-commissions-reporting.KRT_SAP.f_obtieneSociedadDesdeMarca`(marca_ds),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_deactivation_date`(),
				1,
				'PEN',
				'POSTPAID',
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_operacion`(TipoMovimiento),
				nombre_distribuidor,
				--TipoProducto,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_categoria_servicio`(ClaseProducto,TipoProducto),
				'COMISION',
				'CARTERA',
				`mm-commissions-reporting.KRT_SAP.f_generadorDeConceptoEnSap`("CARTERA", `mm-commissions-reporting.KRT_SAP.f_generadorPrimeraLetraDeConceptoEnSap`(nombreProducto, clase_mm, desc_mm, concepto_ds),`mm-commissions-reporting.KRT_SAP.f_generadorPrimerDigitoDeOrdenSap`(orden_sap), segmento, desc_mm, tipoMovimiento)


			from `mm-commissions-reporting.KRT_CARTERA.HISTORICO_COMISIONES_CARTERA_FACTURADO`
			where mes_factura_dt=vmes_factura_dt;


			--- PASO 3.2: INSERTO DECOMISIONES

			INSERT `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO`
			(
				mes_factura_dt,
				mes_liquidado,
				id_mes,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca,
				account_id,
				tariff_id,
				tariff_ds,
				distribuidor,
				canal_gekt,
				subcanal,
				seller,
				customer_id,
				customer_dni,
				activation_date,
				segmento,
				tariff_id_origin,
				service_id_origin,
				tariff_ds_origin,
				operation_type,
				service_id,
				concepto_ds_gekt,
				concepto_origen_ds_gekt,
				marco,
				comision,
				campaign_code,
				causa_baja,
				causa_baja_agrup,
				concepto,
				clase_concepto,
				orden,
				sfid_id,
				agrupacion_canal,
				canal,
				subcanal_gekt,
				nombre_comercio,
				service_type,
				order_type_agg,
				bp,
				id_comisionista,
				cif,
				cod_marca,
				cod_segmento,
				sociedad,
				unidades,
				zona_fiscal,
				billing_type_ds,
				operation,
				distribuidor_gekt,
				categoria_servicio_ds,
				clase,
				tipo

			)


			select 
		
				mes_factura_dt,
				mes_decomision_dt,
				mes_decomision_id,
				commission_id,
				id_registro,
				invoice_id,
				estado,
				marca_ds,
				Contrato,
				IdCatalogo,
				NombreProducto,
				`mm-commissions-reporting.KRT_CAPTACION.f_trans_crea_acreedor`(marca_ds, nombre_distribuidor),
				Canal,
				subcanal,
				agente,
				CAST(IdFijo AS STRING),
				DNI_CIF,
				Fecha_Activacion,
				UPPER(TRIM(Segmento)),
				idCatalogoOrigen,
				CAST(IdProductoOrigen AS STRING),
				NombreProductoOrigen,
				TipoMovimiento,
				CAST(IdProducto AS STRING),
				concepto_ds,
				concepto_origen_ds,
				MARCO_RETRIBUTIVO,
				total,
				campana_id,
				CausaBaja,
				CausaBajaGeneral,
				desc_mm,
				clase_mm,
				orden_sap,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_sfid_id`(marca_ds, agente,usuarioCreador),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_agrupacion_canalv1`(mes_factura_dt, marco_retributivo, canal, subcanal),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_canal`(marco_retributivo, canal, subcanal),
				subcanal,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_nombre_comercio`(marca_ds, canal, agente),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_service_type`(TipoProducto),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_order_type_agg`(TipoMovimiento,causaBaja),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_id_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cif_comisionista`(marca_ds, nombre_distribuidor),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cod_marca`(marca_ds),
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_cod_segmento`(segmento),
				`mm-commissions-reporting.KRT_SAP.f_obtieneSociedadDesdeMarca`(marca_ds),
				1,
				'PEN',
				'POSTPAID',
				--`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_operacion`(TipoMovimiento),
				'BAJA',
				nombre_distribuidor,
				--TipoProducto,
				`mm-commissions-reporting.KRT_CARTERA.f_trans_crea_categoria_servicio`(ClaseProducto,TipoProducto),				
				'DECOMISION',
				'CARTERA',

			from `mm-commissions-reporting.KRT_CARTERA.HISTORICO_DECOMISIONES_CARTERA_FACTURADO`
			where mes_factura_dt=vmes_factura_dt;
		
		END IF;

		--- PASO 4: ACTUALIZO TABLA TRANSACCIONES
		--DELETE FROM `mm-commissions-reporting.KRT_CAPTACION.HISTORICO_COMISIONES_CAPTACION_FACTURADO` where mes_comision_dt=vmes_comision_dt;

		DELETE FROM `mm-commissions-reporting.KRT_SAP.TRANSACCIONES` where mes_factura_dt=VMES_FACTURA_DT;	
		INSERT INTO `mm-commissions-reporting.KRT_SAP.TRANSACCIONES`  SELECT * FROM `mm-commissions-reporting.KRT_SAP.TRANSACCIONES_EN_PROCESO`;

	END IF;
		
END